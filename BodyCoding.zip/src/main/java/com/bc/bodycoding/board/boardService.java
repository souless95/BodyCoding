package com.bc.bodycoding.board;

public interface boardService {

}
