package com.bc.bodycoding.calendar;

import lombok.Data;

@Data
public class CalendarDTO {
	
	private String id;
	private String title;
	private String start1;
	private String end;
}
