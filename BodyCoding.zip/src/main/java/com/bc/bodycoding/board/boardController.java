package com.bc.bodycoding.board;

public class boardController {
	
}
