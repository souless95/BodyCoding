package com.bc.bodycoding;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BodyCodingApplication {

	public static void main(String[] args) {
		SpringApplication.run(BodyCodingApplication.class, args);
	}

}
